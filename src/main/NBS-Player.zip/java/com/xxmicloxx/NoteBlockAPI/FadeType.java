package com.xxmicloxx.NoteBlockAPI;

public enum FadeType {
    FADE_LINEAR
}
