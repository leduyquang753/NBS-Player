package com.xxmicloxx.NoteBlockAPI;

import net.minecraftforge.fml.common.eventhandler.Event;

public class SongEndEvent extends Event {
	public SongEndEvent() {
		super();
	}
}
