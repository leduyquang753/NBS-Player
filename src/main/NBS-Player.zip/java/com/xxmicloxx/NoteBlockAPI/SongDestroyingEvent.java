package com.xxmicloxx.NoteBlockAPI;

import net.minecraftforge.fml.common.eventhandler.Event;

public class SongDestroyingEvent extends Event {
	public SongDestroyingEvent() {
		super();
	}
}
