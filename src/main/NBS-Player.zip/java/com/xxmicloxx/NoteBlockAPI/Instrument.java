package com.xxmicloxx.NoteBlockAPI;

public class Instrument {

    public static String getInstrument(byte instrument) {
        switch (instrument) {
            case 0:
                return "block.note.harp";
            case 1:
                return "block.note.bass";
            case 2:
                return "block.note.basedrum";
            case 3:
                return "block.note.snare";
            case 4:
                return "block.note.hat";
            default:
                return "block.note.harp";
        }
    }
}